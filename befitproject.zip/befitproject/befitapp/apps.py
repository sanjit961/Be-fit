from django.apps import AppConfig


class BefitappConfig(AppConfig):
    name = 'befitapp'
