from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from befitapp.models import ContactUs, register
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
# Create your views here.
def home(request):
    return render(request,"home.html")

def about(request):
    return render(request,"about.html")

def hf(request):
    return render(request,"headerfooter.html")

def contactus(request):
    context = {}
    if request.method == "POST":
        #print(request.POST)
        un = request.POST["cUserName"]
        em = request.POST["cUserEmail"]
        msg = request.POST["cUserMsg"]

        #save data
        data = ContactUs(username=un, email=em, message=msg)
        data.save()
        context["submit_status"] = "Thanks for your feedback! It will help us in many ways."

    return render(request, "contactus.html", context)

def classes(request):
    return render(request, "classes.html")

def blog(request):
    return render(request, "blog.html")

def logins(request):
    context = {}
    if request.method == "POST":
        lgnem = request.POST["lgnEmail"]
        lgnPas = request.POST["lgnPass"]

        check = authenticate(username=lgnem, password=lgnPas)
        if check:
            login(request,check)
            return HttpResponseRedirect("/dashboard")
        else:
            context["error"] = "Invalid Login Details! Try again."
    return render(request, "login.html", context)

def signup(request):
    context = {}
    if request.method == "POST":
        newun = request.POST["rUsrNm"]
        newem = request.POST["rUserEmail"]
        newcn = request.POST["rUserPhone"]
        newpass = request.POST["rUserPass"]

        #check username exists or not
        check = User.objects.filter(username=newun)
        if len(check) ==0:
            usr = User.objects.create_user(newun,newem,newpass)
            usr.save()

            reg = register(user=usr, contact_number=newcn)
            reg.save()

            context["status"] = "Thankyou for registering!"
        else:
            return HttpResponse("username exist")
    
    return render(request, "signup.html", context)
    
def dashboard(request):
    context = {}
    all = register.objects.filter(user__id=request.user.id).order_by("-id")
    context["all"] = all
    return render(request, "dashboard.html", context)

def userlogout(request):
    logout(request)
    return HttpResponseRedirect("/")
