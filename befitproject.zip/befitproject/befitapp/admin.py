from django.contrib import admin
from befitapp.models import ContactUs,register

admin.site.site_header="BeFit Admin Panel"

class ContactUsAdmin(admin.ModelAdmin):
    list_display = ["username", "email", "message", "date"]
    list_filter = ["date"]
    #list_editable = ["message"]
    search_fields = ["date", "username", "email"]

admin.site.register(ContactUs, ContactUsAdmin)
admin.site.register(register)

